// @flow
import app from './server'
import http from 'http'

const server = http.createServer(app)

let currentApp = app

server.listen(process.env.PORT || 3000, error => {
  if (error) {
    console.log(error)
  }

  console.log('🚀 started')
}) // $FlowFixMe
if (module.hot) {
  console.log('✅  Server-side HMR Enabled!')
  // $FlowFixMe
  module.hot.accept('./server', () => {
    console.log('🔁  HMR Reloading `./server`...')
    server.removeListener('request', currentApp)
    const newApp = require('./server').default
    server.on('request', newApp)
    currentApp = newApp
  })
}
